# Freelanzo static site

This folder is ready for GitHub Pages.

## Files
- `index.html` — main website page
- `assets/` — local images and favicon extracted from the original HTML
- `.nojekyll` — keeps GitHub Pages from applying Jekyll processing

## Deploy on GitHub Pages
Upload these files to a GitHub repository, then enable GitHub Pages from the repository settings.
