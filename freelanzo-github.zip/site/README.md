# Freelanzo

Website for Freelanzo, a gig event staffing platform in Bangalore. Hire event staff or find one day event jobs.

## Files
| File | Purpose |
|---|---|
| `index.html` | The website (single file, images embedded) |
| `favicon.ico`, `favicon-16x16.png`, `favicon-32x32.png`, `favicon.png` | Browser tab icons |
| `apple-touch-icon.png` | iPhone/iPad home screen icon |
| `android-chrome-*.png`, `site.webmanifest` | Android / PWA icons |
| `og-image.jpg` | Preview image for WhatsApp, Facebook, LinkedIn, X |
| `robots.txt`, `sitemap.xml` | Search engine crawling |
| `404.html` | Custom not-found page |
| `.nojekyll` | Tells GitHub Pages to serve files as-is |

## Before going live
Replace `https://YOUR-DOMAIN.com` with your real domain in `index.html`, `robots.txt` and `sitemap.xml`:

```bash
sed -i 's#https://YOUR-DOMAIN.com#https://yourdomain.com#g' index.html robots.txt sitemap.xml
```

## Deploy on GitHub Pages
1. Create a repo, upload all these files to the root, commit.
2. Repo **Settings > Pages > Source: Deploy from a branch > main / (root)**.
3. For a custom domain, add it under **Pages > Custom domain** (GitHub creates the `CNAME` file) and set DNS at your registrar.
4. Tick **Enforce HTTPS**.

## After launch (SEO)
- Add the site to Google Search Console, then submit `https://yourdomain.com/sitemap.xml`.
- Add a Google Business Profile for Bangalore for local search.
- Test the share preview at https://developers.facebook.com/tools/debug/
