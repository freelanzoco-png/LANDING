# Freelanzo – Hire Event Staff & Find One Day Event Jobs

India's Gig Event Staffing & Gig Work Platform, based in Bangalore.

- Phone / WhatsApp: +91 9620055756
- Instagram: https://www.instagram.com/freelanzo_/

## Files
| File | Purpose |
|---|---|
| `index.html` | The website (SEO meta tags, FAQ and structured data included) |
| `favicon.png`, `favicon.ico`, `apple-touch-icon.png` | Site icons |
| `robots.txt` | Lets Google, ChatGPT and other crawlers read the site |
| `sitemap.xml` | Sitemap for Google Search Console |
| `llms.txt` | Plain summary for AI tools |
| `.nojekyll` | Tells GitHub Pages to serve files as they are |

## Before going live
Replace `YOURDOMAIN.com` in `robots.txt` and `sitemap.xml` with your real website address.
